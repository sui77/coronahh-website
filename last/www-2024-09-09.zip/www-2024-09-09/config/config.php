<?php

return
    [
        "mysql" => [
            "host" => "coronahh-db",
            "user" => "application",
            "password" => file_get_contents(dirname(__FILE__) . '/db/APPLICATION_PW'),
            "charset" => "utf8",
            "database" => "application"
        ],
        "settings" => [
            "dev" => false,
            "caching" => true,
            "plausible" => true
        ]
    ];