<?php

class Impressum extends AbstractController {

    protected $_template = 'impressum';

    public function action() {
    }

}